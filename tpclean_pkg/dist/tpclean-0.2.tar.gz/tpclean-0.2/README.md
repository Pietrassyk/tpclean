# tpclean
home of the tpclean library

# Note for myself
to upload new version use:
python -m twine upload dist/*
tpclean folder
