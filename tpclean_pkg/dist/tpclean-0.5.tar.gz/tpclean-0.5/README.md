# tpclean
home of the tpclean library

### Notes for myself
#to build new package
python3 setup.py sdist bdist_wheel

#to upload new version use:

python -m twine upload dist/*
tpclean folder
