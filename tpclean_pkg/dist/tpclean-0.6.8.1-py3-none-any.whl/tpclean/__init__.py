"""
TpClean
=======

This is the tpclean Library for Data Cleaning,
use import tpclean.tpclean for functions import
until I figured out how to do this automatically.

If you want to contribute, see https://github.com/Pietrassyk/tpclean

Feel free to rech out to me via Email:
pietrassyk@gmail.com
"""

name = "tpclean"
version = "0.6"
__all__ = ["tpclean"]

tgtower = "<3"


from . import tpclean
from tpclean import *



